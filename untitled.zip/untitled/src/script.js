<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Modulo AIR Teknic</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<style>
    body { font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: auto; background: #f7f7f7; }
    h1, h2 { text-align: center; color: #007acc; }
    label { display: block; margin-top: 10px; }
    input, textarea, select { width: 100%; padding: 6px; margin-top: 5px; }
    fieldset { margin-top: 20px; padding: 15px; border: 1px solid #ccc; }
    legend { font-weight: bold; color: #007acc; }
    button { margin-top: 20px; padding: 10px 20px; background-color: #007acc; color: white; border: none; cursor: pointer; }
    button:hover { background-color: #005f99; }
</style>
</head>
<body>

<h1>AIR Teknic - Modulo Intervento</h1>

<form id="modulo">

<fieldset>
<legend>Dati Cliente</legend>
<label>Nome Cliente:
    <input type="text" id="nomeCliente" value="">
</label>
<label>Indirizzo:
    <input type="text" id="indirizzoCliente" value="">
</label>
</fieldset>

<fieldset>
<legend>Dati Intervento</legend>
<label>Data intervento:
    <input type="date" id="dataIntervento" value="Data">
</label>
<label>Tecnico incaricato:
    <input type="text" id="tecnico" value="Airteknic">
</label>
<label>Tipo impianto refrigerante:
    <select id="tipoImpianto">
        <option value="Mono Split" selected>Mono Split</option>
        <option value="Multi Split">Multi Split</option>
        <option value="Centralizzato">Centralizzato</option>
        <option value="Canalizzato">Canalizzato</option>
        <option value="Predisposto">Predisposto</option>
    </select>
</label>
</fieldset>

<fieldset>
<legend>Motivo della chiamata</legend>
<label><input type="checkbox" id="raffreddamento"> Mancato raffreddamento</label>
<label><input type="checkbox" id="perditeGas"> Perdite gas refrigerante</label>
<label><input type="checkbox" id="rumori"> Rumori anomali</label>
<label><input type="checkbox" id="ricercaPerdita"> Sospetta perdita / ricerca perdita</label>
<label><input type="checkbox" id="manutenzione"> Manutenzione ordinaria</label>
<label><input type="checkbox" id="installazione"> Installazione</label>
<label>Altro:
    <input type="text" id="altro" placeholder="Specificare, se installazione ,che tipo di installazione bisogna fare">
</label>
</fieldset>

<fieldset>
<legend>Lavori eseguiti con eventuale prezzario</legend>
<textarea id="lavoriEseguiti" rows="6"></textarea>
</fieldset>

<fieldset>
<legend>Materiali utilizzati con eventuale prezzario</legend>
<textarea id="materiali" rows="8"></textarea>
</fieldset>

<fieldset>
<legend>Verifiche finali</legend>
<label><input type="checkbox" checked> Prova di tenuta eseguita
<label><input type="checkbox" checked> Controllo pressione gas
<label><input type="checkbox" checked> Controllo assorbimenti
<label><input type="checkbox" checked> Test rendimento
<label><input type="checkbox" checked> Collaudo finale superato
</fieldset>

<fieldset>
<legend>Note aggiuntive</legend>
<textarea id="note" rows="4"></textarea>
</fieldset>

<h1>AIR Teknic - il comfort che meriti </h1>

<button type="button" onclick="generaPDF()">Genera PDF</button>

</form>

<script>
async function generaPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });

    let y = 20;
    const lineHeight = 7;

    function addText(title, value) {
        doc.setFontSize(12);
        doc.text(title, 20, y);
        y += lineHeight;
        doc.setFontSize(11);
        let splitText = doc.splitTextToSize(value, 170);
        doc.text(splitText, 20, y);
        y += splitText.length * lineHeight + 3;
    }

    doc.setFontSize(16);
    doc.text("AIR Teknic - Modulo Intervento", 105, y, null, null, "center");
    y += 10;

    addText("Nome Cliente:", document.getElementById('nomeCliente').value);
    addText("Indirizzo:", document.getElementById('indirizzoCliente').value);
    addText("Data Intervento:", document.getElementById('dataIntervento').value);
    addText("Tecnico incaricato:", document.getElementById('tecnico').value);
    addText("Tipo Impianto Refrigerante:", document.getElementById('tipoImpianto').value);

    const motivi = [];
    if(document.getElementById('raffreddamento').checked) motivi.push("Mancato raffreddamento");
    if(document.getElementById('perditeGas').checked) motivi.push("Perdite gas refrigerante");
    if(document.getElementById('rumori').checked) motivi.push("Rumori anomali");
    if(document.getElementById('ricercaPerdita').checked) motivi.push("Sospetta perdita / ricerca perdita");
    if(document.getElementById('manutenzione').checked) motivi.push("Manutenzione ordinaria");
    if(document.getElementById('installazione').checked) motivi.push("Installazione");
    if(document.getElementById('altro').value) motivi.push("Altro: " + document.getElementById('altro').value);

    addText("Motivo della chiamata:", motivi.join(", "));
    addText("Lavori eseguiti:", document.getElementById('lavoriEseguiti').value);
    addText("Materiali utilizzati:", document.getElementById('materiali').value);

    const verifiche = [];
    document.querySelectorAll("fieldset:nth-of-type(6) input[type=checkbox]").forEach(cb => {
        if(cb.checked) verifiche.push(cb.parentNode.textContent.trim());
    });
    addText("Verifiche finali:", verifiche.join(", "));
    addText("Note aggiuntive:", document.getElementById('note').value);

    y += 10;
    doc.setFontSize(12);
    doc.text("AIR Teknic - Il comfort che meriti, firmato AIR Teknic.", 105, y, null, null, "center");

    const filename = `Modulo_AIR_Teknic_${document.getElementById('nomeCliente').value.replace(/ /g,"_")}.pdf`;
    doc.save(filename);
    alert("PDF generato! Puoi inviarlo via email o WhatsApp.");
}
</script>

</body>
</html>
